import hashlib
import datetime

# -------------------------------
# Block Class
# Represents a single block in the blockchain
# -------------------------------
class Block:
    def __init__(self, index, data, previous_hash):
        self.index = index                      # Position of block in chain
        self.timestamp = datetime.datetime.now() # Time of creation
        self.data = data                        # Transaction or stored data
        self.previous_hash = previous_hash      # Hash of previous block
        self.hash = self.generate_hash()        # Current block hash

    # Function to generate SHA256 hash of the block
    def generate_hash(self):
        # Combine all attributes into a single string
        content = str(self.index) + str(self.timestamp) + str(self.data) + str(self.previous_hash)
        
        # Encode and hash using SHA256
        return hashlib.sha256(content.encode()).hexdigest()


# -------------------------------
# Blockchain Class
# Manages the chain of blocks
# -------------------------------
class SimpleBlockchain:
    def __init__(self):
        self.chain = []                 # List to store blocks
        self.create_first_block()       # Create genesis block

    # Create the first block (no previous block exists)
    def create_first_block(self):
        genesis_block = Block(0, "Genesis Block", "0")
        self.chain.append(genesis_block)

    # Add a new block to the chain
    def add_block(self, data):
        last_block = self.chain[-1]     # Get the last block in chain
        
        # Create new block using last block's hash
        new_block = Block(len(self.chain), data, last_block.hash)
        
        self.chain.append(new_block)

    # Display all blocks in the chain
    def show_chain(self):
        for block in self.chain:
            print(f"\nBlock {block.index}")
            print("Timestamp     :", block.timestamp)
            print("Data          :", block.data)
            print("Previous Hash :", block.previous_hash)
            print("Hash          :", block.hash)

    # Verify integrity of blockchain
    def verify_chain(self):
        for i in range(1, len(self.chain)):
            current = self.chain[i]
            previous = self.chain[i - 1]

            # Check if link between blocks is broken
            if current.previous_hash != previous.hash:
                return False

        return True


# -------------------------------
# Testing the Blockchain
# -------------------------------
if __name__ == "__main__":
    blockchain = SimpleBlockchain()

    # Adding blocks with sample data
    blockchain.add_block("A sends 10 coins to B")
    blockchain.add_block("B sends 5 coins to C")
    blockchain.add_block("C sends 2 coins to D")
    blockchain.add_block("D sends 1 coin to E")

    print("=== Original Blockchain ===")
    blockchain.show_chain()

    print("\nIs blockchain valid?", blockchain.verify_chain())

    # -------------------------------
    # Tampering demonstration
    # -------------------------------
    print("\n=== After Tampering ===")
    
    # Modify data of a block
    blockchain.chain[2].data = "HACKED DATA"
    
    # Recalculate hash of tampered block
    blockchain.chain[2].hash = blockchain.chain[2].generate_hash()

    blockchain.show_chain()

    # Validation should now fail
    print("\nIs blockchain valid?", blockchain.verify_chain())