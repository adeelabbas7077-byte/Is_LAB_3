# ==========================================
# Elliptic Curve: y^2 = x^3 + ax + b mod p
# Using small numbers for learning purposes
# ==========================================

p = 17   # Prime modulus
a = 2
b = 2

# Base point (must satisfy curve equation)
G = (5, 1)


# ==========================================
# Modular inverse using Python built-in pow
# ==========================================
def mod_inverse(k, p):
    return pow(k, -1, p)


# ==========================================
# Point Addition: P + Q
# ==========================================
def point_add(P, Q):
    # If P == Q, use doubling formula
    if P == Q:
        return point_double(P)

    x1, y1 = P
    x2, y2 = Q

    # Calculate slope (m)
    m = ((y2 - y1) * mod_inverse(x2 - x1, p)) % p

    # Calculate resulting point
    x3 = (m*m - x1 - x2) % p
    y3 = (m*(x1 - x3) - y1) % p

    return (x3, y3)


# ==========================================
# Point Doubling: 2P
# ==========================================
def point_double(P):
    x, y = P

    # Calculate slope (m)
    m = ((3*x*x + a) * mod_inverse(2*y, p)) % p

    # Calculate resulting point
    x3 = (m*m - 2*x) % p
    y3 = (m*(x - x3) - y) % p

    return (x3, y3)


# ==========================================
# Scalar Multiplication: k * P
# (Repeated addition)
# ==========================================
def scalar_multiply(k, P):
    result = P

    for _ in range(k - 1):
        result = point_add(result, P)

    return result


# ==========================================
# Inverse of a point (used in decryption)
# ==========================================
def inverse_point(P):
    x, y = P
    return (x, (-y) % p)


# ==========================================
# MAIN PROGRAM (Testing)
# ==========================================
if __name__ == "__main__":

    # ------------------------------
    # Key Generation
    # ------------------------------
    private_key = 3                      # chosen small integer
    public_key = scalar_multiply(private_key, G)

    print("Private Key:", private_key)
    print("Public Key :", public_key)

    # ------------------------------
    # Message Encoding
    # Convert number → point
    # ------------------------------
    message = 7
    M = scalar_multiply(message, G)

    print("\nMessage as Point:", M)

    # ------------------------------
    # Encryption (EC-ElGamal simplified)
    # ------------------------------
    k = 2   # random number

    C1 = scalar_multiply(k, G)
    C2 = point_add(M, scalar_multiply(k, public_key))

    print("\nEncrypted:")
    print("C1:", C1)
    print("C2:", C2)

    # ------------------------------
    # Decryption
    # ------------------------------
    temp = scalar_multiply(private_key, C1)

    # Subtract by adding inverse
    decrypted = point_add(C2, inverse_point(temp))

    print("\nDecrypted Point:", decrypted)